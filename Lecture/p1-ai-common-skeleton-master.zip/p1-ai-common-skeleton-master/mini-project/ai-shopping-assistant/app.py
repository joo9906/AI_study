# app.py
import gradio as gr
import torch
import numpy as np
from PIL import Image
import cv2
from ultralytics import YOLO
# CLIP 관련 imports를 transformers로 대체
from transformers import CLIPProcessor, CLIPModel
from transformers import AutoTokenizer, AutoModelForCausalLM
from langchain_huggingface import HuggingFaceEmbeddings
from langchain_community.vectorstores import Chroma
from langchain.text_splitter import CharacterTextSplitter
from langchain.chains import ConversationalRetrievalChain
from langchain.memory import ConversationBufferMemory
from langchain_community.llms import HuggingFacePipeline
import requests
import os
from config import *
from utils import TokenManager

# 전역 변수
models = {}
vector_store = None
conversation_chain = None
search_count = 0
token_manager = None

def load_models():
    """
    모든 AI 모델을 로드하고 초기화합니다.
    - YOLO: 패션 아이템 객체 탐지
    - CLIP: 이미지-텍스트 임베딩
    - LLM: 대화형 AI
    - Vector Store: 상품 정보 저장 및 검색
    """
    global models, vector_store, conversation_chain, token_manager
    
    # YOLOv8 DeepFashion2 모델 로드
    print("YOLO 모델 로딩 중...")
    models['yolo'] = YOLO(YOLO_MODEL_PATH, task='detect')
    
    # CLIP 모델 로드 (transformers 라이브러리 사용)
    print("CLIP 모델 로딩 중...")
    device = "cuda" if torch.cuda.is_available() else "cpu"
    models['device'] = device
    
    # Hugging Face의 CLIP 모델 사용
    # 기본적으로 openai/clip-vit-base-patch32 모델 사용
    clip_model_name = CLIP_MODEL_PATH
    models['clip_processor'] = CLIPProcessor.from_pretrained(clip_model_name)
    models['clip_model'] = CLIPModel.from_pretrained(clip_model_name).to(device)
    
    # LLM 모델 로드
    print("LLM 모델 로딩 중...")
    tokenizer = AutoTokenizer.from_pretrained(LLM_MODEL_PATH, use_fast=False)
    # pad_token이 없는 경우 eos_token으로 설정
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token
        
    # GPU 사용 명시적 설정
    model = AutoModelForCausalLM.from_pretrained(
        LLM_MODEL_PATH,
        torch_dtype=torch.float16,
        device_map="auto" if torch.cuda.is_available() else None,
        low_cpu_mem_usage=True
    )
    
    # GPU 사용 확인
    if torch.cuda.is_available():
        print(f"LLM이 GPU에서 실행됩니다: {torch.cuda.get_device_name()}")
    else:
        print("LLM이 CPU에서 실행됩니다")
    
    # TokenManager 초기화
    token_manager = TokenManager(tokenizer)
    
    # LangChain 설정
    pipeline_kwargs = {
        "temperature": 0.7, 
        "max_length": 512,
        "do_sample": True,
        "top_p": 0.9
    }
    
    llm = HuggingFacePipeline.from_model_id(
        model_id=LLM_MODEL_PATH,
        task="text-generation",
        model_kwargs=pipeline_kwargs
    )
    
    # 벡터 스토어 초기화
    print("벡터 스토어 초기화 중...")
    embeddings = HuggingFaceEmbeddings(
        model_name=EMBEDDING_MODEL_PATH
    )

    
    # ChromaDB 디렉토리가 없으면 생성
    if not os.path.exists(CHROMA_PERSIST_DIR):
        os.makedirs(CHROMA_PERSIST_DIR)
    
    vector_store = Chroma(
        persist_directory=CHROMA_PERSIST_DIR,
        embedding_function=embeddings, 
    )
    
    # 대화 체인 설정
    memory = ConversationBufferMemory(
        memory_key="chat_history",
        return_messages=True,
        output_key="answer"
    )
    
    
    
    models['tokenizer'] = tokenizer
    models['image_vectorstore'] = setup_image_vectorstore()
    models['llm'] = model
    
    print("모든 모델 로딩 완료!")
    return models

# 색상 탐색에 필요한 함수들 - 이미지 평균을 사용해서 검색 예정, RGB 색상으로 사용할거임.
def crop_image_by_bbox(image, bbox):
    x1, y1, x2, y2 = bbox
    return image[y1:y2, x1:x2]

def extract_dominant_color(image):
    """
    이미지에서 가장 지배적인 색상을 추출합니다.
    Args:
        image: OpenCV 형식의 이미지 (numpy array)  
    Returns:
        대표 색상 (RGB 형식)
    """
    # 이미지를 RGB로 변환
    image_rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
    
    # 이미지 크기 조정 (속도 향상을 위해)
    resized_image = cv2.resize(image_rgb, (100, 100))
    
    # 평균 색상 계산
    average_color = np.mean(resized_image, axis=(0, 1))
    
    return tuple(map(int, average_color))

def convert_color_to_name(color):
    # OpenCV는 BGR 형식이므로 RGB로 변환
    color_rgb = tuple(int(c) for c in color[::-1])
    
    # 색상 이름 사전 정의
    color_names = {
        (255, 0, 0): "빨강",
        (0, 255, 0): "초록",
        (0, 0, 255): "파랑",
        (255, 255, 0): "노랑",
        (255, 165, 0): "주황",
        (128, 0, 128): "보라",
        (192, 192, 192): "은색",
        (0, 0, 0): "검정",
        (255, 255, 255): "흰색"
    }
    
    # 가장 가까운 색상 찾기
    closest_color = min(color_names.keys(), key=lambda k: np.linalg.norm(np.array(k) - np.array(color_rgb)))
    
    return color_names[closest_color]

def cloth_color(image, bbox):
    cropped_region = crop_image_by_bbox(image, bbox) # 이미지에서 바운딩 박스 영역을 자름
    representative_color = extract_dominant_color(cropped_region) # 대표 색상 추출
    color_name = convert_color_to_name(representative_color) # 색상을 한국어로 변환
    
    return color_name


def detect_fashion_objects(image):
    """
    업로드된 이미지에서 패션 아이템을 탐지합니다.
    
    Args:
        image: PIL Image 객체
        
    Returns:
        img_with_boxes: 바운딩 박스가 그려진 이미지
        html_output: HTML 형식의 탐지 결과
    """
    if image is None:
        return None, "<p>이미지를 업로드해주세요.</p>"
    
    try:
        # YOLO 모델로 객체 탐지 실행
        results = models['yolo'](image)
        
        # 이미지 복사본에 바운딩 박스 그리기
        img_with_boxes = np.array(image).copy()
        detected_items = []
        
        # 디버깅 출력
        print(f"YOLO 탐지 결과 수: {len(results)}")
        
        for r in results:
            boxes = r.boxes
            if boxes is not None:
                print(f"박스 수: {len(boxes)}")
                for box in boxes:
                    # 바운딩 박스 좌표 추출
                    x1, y1, x2, y2 = box.xyxy[0].tolist()
                    conf = box.conf[0].item()  # 신뢰도
                    cls = int(box.cls[0].item())  # 클래스 ID
                    class_name = models['yolo'].names[cls]  # 클래스 이름
                    
                    print(f"탐지된 아이템: {class_name} (신뢰도: {conf:.2f})")
                    
                    # 바운딩 박스와 레이블 그리기
                    cv2.rectangle(img_with_boxes, (int(x1), int(y1)), (int(x2), int(y2)), (0, 255, 0), 2)
                    cv2.putText(img_with_boxes, f"{class_name} {conf:.2f}", 
                               (int(x1), int(y1-10)), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 2)
                    
                    bbox = (int(x1), int(y1), int(x2), int(y2))
                    color_name = cloth_color(np.array(image), bbox)  # 색상 추출
                    item_with_color = f"{class_name} ({color_name})"
                    
                    detected_items.append(item_with_color)
                    print(f"탐지된 아이템 색상!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!: {item_with_color}")
        
        # PIL Image로 변환
        img_with_boxes = Image.fromarray(img_with_boxes)
        
        if detected_items:
            print(f"총 탐지된 아이템: {detected_items}")
            
            # 탐지된 아이템으로 초기 상품 검색
            products = search_products(' '.join(detected_items[:2]))
            save_products_to_vectorstore(products)
            
            # HTML 출력 생성
            html_output = f"<h3>탐지된 아이템</h3><p>{', '.join(detected_items)}</p><hr>"
            html_output += format_product_html(products)
            
            
        else:
            html_output = "<p>패션 아이템을 찾을 수 없습니다.</p>"
        
        return img_with_boxes, html_output
        
    except Exception as e:
        print(f"이미지 탐지 오류: {e}")
        import traceback
        traceback.print_exc()
        return image, f"<p>오류가 발생했습니다: {str(e)}</p>"



# 여기서부터 CLIP 관련 백터화 진행할거임. extract는 이미 있던거
def prepare_product_metadata(product):
    # CLIP 벡터 형식에 맞게 가공
    return {
        'title': product.get('title', ''),
        'link': product.get('link', ''),
        'price': product.get('lprice', '0'),
        'hprice': product.get('hprice', '0'),
        'mall': product.get('mallName', ''),
        'image': product.get('image', ''),
        'productId': str(product.get('productId', '')),
        'brand': product.get('brand', ''),
        'maker': product.get('maker', ''),
        'category1': product.get('category1', ''),
        'category2': product.get('category2', '')
    }

def generate_unique_ids(products):
    # 상품 고유의 id 생성, 이건 uuid 같은걸로 해도 상관 없을 듯
    return [str(p.get('productId', i)) for i, p in enumerate(products)]

def convert_vectorstore_results_to_products(results):
    # 벡터 스토어 검색 결과를 상품 형태로 변환
    products = []
    for doc in results:
        if doc.metadata:
            products.append({
                'title': doc.metadata.get('title', ''),
                'link': doc.metadata.get('link', ''),
                'lprice': doc.metadata.get('price', '0'),
                'hprice': doc.metadata.get('hprice', '0'),
                'mallName': doc.metadata.get('mall', ''),
                'image': doc.metadata.get('image', 'https://placehold.co/150'),
                'productId': doc.metadata.get('productId', ''),
                'brand': doc.metadata.get('brand', ''),
                'maker': doc.metadata.get('maker', ''),
                'category1': doc.metadata.get('category1', ''),
                'category2': doc.metadata.get('category2', '')
            })
    return products

def has_valid_image_url(product):
    # 이미지url이 있는지 확인, placeholder가 아닌지도 검사
    url = product.get('image', '')
    return url and 'placeholder' not in url

from io import BytesIO
def download_and_preprocess_image(image_url):
    # 이미지 받아와서 변환 + 사이즈 조정
    response = requests.get(image_url)
    image = Image.open(BytesIO(response.content)).convert("RGB")
    image = image.resize((224, 224))  # CLIP 모델 입력 크기에 맞게 조정
    return image

def run_yolo_detection(image):
    # 욜로 모델을 사용하여 이미지에서 패션 아이템 탐지
    results = models['yolo'](image)
    detected_items = []
    
    for r in results:
        boxes = r.boxes
        if boxes is not None:
            for box in boxes:
                x1, y1, x2, y2 = box.xyxy[0].tolist()
                cls = int(box.cls[0].item())  # 클래스 ID
                class_name = models['yolo'].names[cls]  # 클래스 이름
                color_name = "색상 모름0"
                bbox = (int(x1), int(y1), int(x2), int(y2))
                try:
                    color_name = cloth_color(np.array(image), bbox)  # 색상 추출
                except Exception as e:
                    print(f"Color detection error: {e}")
                    color_name = "색상 모름"
                detected_items.append(f"{class_name} ({color_name})")
    
    return detected_items

def merge_and_deduplicate_products(list1, list2):  
    # 리스트 받아와서 중복 제거  
    seen_ids = set()
    merged = []
    
    for product in list1 + list2:
        pid = product.get('productId')
        if pid and pid not in seen_ids:
            seen_ids.add(pid)
            merged.append(product)
    
    return merged

def extract_clip_features(image):
    """
    CLIP 모델을 사용하여 이미지의 특징 벡터를 추출합니다.
    
    Args:
        image: PIL Image 객체
        이미지를 CLIP 모델에 맞게 전처리
        
    Returns:
        features: 이미지 특징 벡터 (numpy array)
    """
    # CLIP 프로세서로 이미지 전처리
    inputs = models['clip_processor'](images=image, return_tensors="pt")
    inputs = {k: v.to(models['device']) for k, v in inputs.items()}
    
    # 특징 추출
    with torch.no_grad():
        image_features = models['clip_model'].get_image_features(**inputs)
    
    return image_features.cpu().numpy()

def setup_image_vectorstore():
    "CLIP 이미지 벡터 저장용 별도 ChromaDB 설정"
    
    # CLIP 모델은 HuggingFaceEmbeddings와 직접 호환되지 않으므로,
    # 임베딩 함수 없이 ChromaDB를 초기화합니다.
    # 벡터는 사전에 직접 계산하여 저장합니다.
    image_collection = Chroma(
        collection_name="product_images",
        persist_directory="./chroma_db_images",
        embedding_function=None
    )
    
    return image_collection

def save_products_with_clip_vectors(products):
    image_vectors = []
    metadatas = []
    valid_products = []
    
    # 상품에서 유효한 이미지(has_valid_url)만 골라 다운로드 + 전처리 후 임베딩 벡터 추출 
    for product in products:
        if has_valid_image_url(product):
            try:
                image = download_and_preprocess_image(product['image'])
                clip_vector = extract_clip_features(image)
                image_vectors.append(clip_vector.flatten().tolist())
                metadatas.append(prepare_product_metadata(product))
                valid_products.append(product)
            except Exception as e:
                print(f"이미지 처리 실패 {product.get('productId')}: {e}")

    if not image_vectors:
        return

    # 추출한 벡터와 데이터를 image_vectors에 저장
    image_texts = [str(p.get('title') or "상품명 없음") for p in valid_products]
    
    models['image_vectorstore']._collection.add(
        embeddings = image_vectors,
        metadatas=metadatas,
        documents = image_texts,
        ids=generate_unique_ids(valid_products)
    )

def search_similar_images(user_image, k=5):
    # 기존 extrract_clip_features 함수 사용, 사용자가 업로드한 이미지 벡터화
    user_clip_vector = extract_clip_features(user_image)
    
    # 이미지 벡터 스토어에서 유사도 검색
    search_results = models['image_vectorstore'].similarity_search_by_vector(
        embedding=user_clip_vector.flatten().tolist(),
        k=k
    )
    
    # 검색 겨로가를 상품 형태로 변환
    similar_products = convert_vectorstore_results_to_products(search_results)
    return similar_products
    
def integrate_clip_search_to_detection(image):
    # 기존 욜로 탐지
    detected_items = run_yolo_detection(image)
    
    # 기존 텍스트 기반 상품 검색
    text_products = search_products(' '.join(detected_items))
    
    # 새로 검색된 상품들을 CLIP 벡터로 저장
    if text_products:
        save_products_with_clip_vectors(text_products)
        
    # 업로드 된 이미지로 유사 상품 검색
    similar_products = search_similar_images(image)
    print("🔍 유사 이미지 검색 결과 개수:", len(similar_products))
    
    # 결과 통합 및 중복 제거
    combined_products = merge_and_deduplicate_products(text_products, similar_products)

    return format_product_html(combined_products)





def search_products(query):
    """
    네이버 쇼핑 API를 사용하여 상품을 검색합니다.
    API 호출 횟수 제한이 있으면 벡터 스토어에서 검색합니다.
    
    Args:
        query: 검색어
        
    Returns:
        products: 상품 리스트
    """
    global search_count
    
    # 검색 횟수 제한 확인
    if search_count >= MAX_SEARCH_COUNT:
        return search_from_vectorstore(query)
    
    # 네이버 API 키가 설정되지 않은 경우 더미 데이터 반환
    if not NAVER_CLIENT_ID or NAVER_CLIENT_ID == "YOUR_NAVER_CLIENT_ID":
        return generate_dummy_products(query)
    
    # 네이버 쇼핑 API 호출
    url = "https://openapi.naver.com/v1/search/shop.json"
    headers = {
        "X-Naver-Client-Id": NAVER_CLIENT_ID,
        "X-Naver-Client-Secret": NAVER_CLIENT_SECRET
    }
    params = {"query": query, "display": SEARCH_DISPLAY_COUNT, "sort": "sim"}
    
    try:
        response = requests.get(url, headers=headers, params=params)
        if response.status_code == 200:
            search_count += 1
            items = response.json()['items']
            
            # 데이터 정합성 처리
            # productType이 1, 2, 3인 일반상품만 필터링 (다른 값은 중고이거나, 단종 상품)
            filtered_items = []
            for item in items:
                product_type = int(item.get('productType', 0))
                if product_type in [1, 2, 3]:  # 일반상품만
                    # 데이터 정합성 처리
                    if 'image' not in item or not item['image']:
                        item['image'] = 'https://placehold.co/150'
                    
                    # 가격은 이미 숫자로 제공되므로 문자열로 변환
                    item['lprice'] = str(item.get('lprice', 0))
                    item['hprice'] = str(item.get('hprice', 0))
                    
                    # HTML 태그 제거 (title에 포함된 <b> 태그)
                    if 'title' in item:
                        item['title'] = item['title'].replace('<b>', '').replace('</b>', '')
                    
                    # 추가 필드 확인
                    item['brand'] = item.get('brand', '')
                    item['maker'] = item.get('maker', '')
                    item['category1'] = item.get('category1', '')
                    item['category2'] = item.get('category2', '')
                    
                    filtered_items.append(item)
            
            print(filtered_items)
            return filtered_items
    except Exception as e:
        print(f"API 호출 오류: {e}")
    
    return generate_dummy_products(query)

def generate_dummy_products(query):
    """
    테스트용 더미 상품 데이터를 생성합니다.
    
    Args:
        query: 검색어
        
    Returns:
        products: 더미 상품 리스트
    """
    categories = ['패션의류', '패션잡화', '화장품/미용', '디지털/가전', '가구/인테리어']
    brands = ['브랜드A', '브랜드B', '브랜드C', '브랜드D', '브랜드E']
    
    products = []
    for i in range(SEARCH_DISPLAY_COUNT):
        products.append({
            'title': f'{query} 상품 {i+1}',
            'link': f'https://example.com/product/{i+1}',
            'lprice': str(10000 + i * 5000),
            'hprice': str(15000 + i * 5000),
            'mallName': f'쇼핑몰 {i+1}',
            'image': f'https://placehold.co/150?text=Product{i+1}',
            'productId': 1000000 + i,
            'productType': 1,
            'brand': brands[i % len(brands)],
            'maker': f'제조사 {i+1}',
            'category1': categories[i % len(categories)],
            'category2': '서브카테고리'
        })
    return products

def save_products_to_vectorstore(products):
    """
    검색된 상품 정보를 벡터 스토어에 저장합니다.
    
    Args:
        products: 상품 리스트
    """
    if not products:
        return
    
    texts = []
    metadatas = []
    
    for product in products:
        # 상품 정보를 텍스트로 변환 (검색 효율성을 위해 더 많은 정보 포함)
        text_parts = [
            product.get('title', ''),
            product.get('mallName', ''),
            f"가격: {product.get('lprice', '0')}원",
            product.get('brand', ''),
            product.get('maker', ''),
            product.get('category1', ''),
            product.get('category2', '')
        ]
        text = ' '.join([part for part in text_parts if part])
        texts.append(text)
        
        # 메타데이터 저장 (모든 필드 포함)
        metadatas.append({
            'title': product.get('title', ''),
            'link': product.get('link', ''),
            'price': product.get('lprice', '0'),
            'hprice': product.get('hprice', '0'),
            'mall': product.get('mallName', ''),
            'image': product.get('image', 'https://placehold.co/150'),
            'productId': str(product.get('productId', '')),
            'brand': product.get('brand', ''),
            'maker': product.get('maker', ''),
            'category1': product.get('category1', ''),
            'category2': product.get('category2', '')
        })
    
    # 벡터 스토어에 추가
    vector_store.add_texts(texts=texts, metadatas=metadatas)

def search_from_vectorstore(query):
    """
    벡터 스토어에서 유사한 상품을 검색합니다.
    
    Args:
        query: 검색어
        
    Returns:
        products: 검색된 상품 리스트
    """
    docs = vector_store.similarity_search(query, k=SEARCH_DISPLAY_COUNT)
    products = []
    
    for doc in docs:
        if doc.metadata:
            products.append({
                'title': doc.metadata.get('title', ''),
                'link': doc.metadata.get('link', ''),
                'lprice': doc.metadata.get('price', '0'),
                'hprice': doc.metadata.get('hprice', '0'),
                'mallName': doc.metadata.get('mall', ''),
                'image': doc.metadata.get('image', 'https://placehold.co/150'),
                'productId': doc.metadata.get('productId', ''),
                'brand': doc.metadata.get('brand', ''),
                'maker': doc.metadata.get('maker', ''),
                'category1': doc.metadata.get('category1', ''),
                'category2': doc.metadata.get('category2', '')
            })
    
    return products

def format_product_list(products):
    """
    상품 리스트를 텍스트 형식으로 포맷팅합니다.
    
    Args:
        products: 상품 리스트
        
    Returns:
        formatted: 포맷팅된 상품 정보 문자열
    """
    if not products:
        return "상품을 찾을 수 없습니다."
    
    formatted = "추천 상품:\n"
    for i, product in enumerate(products[:3], 1):
        # 가격 처리 (문자열이거나 숫자일 수 있음)
        try:
            price = int(product.get('lprice', 0))
        except (ValueError, TypeError):
            price = 0
            
        formatted += f"{i}. {product.get('title', '상품명 없음')}\n"
        formatted += f"   가격: {price:,}원\n"
        formatted += f"   쇼핑몰: {product.get('mallName', '정보 없음')}\n"
        formatted += f"   구매하기: {product.get('link', '#')}\n\n"
    
    return formatted

def format_product_html(products):
    """
    상품 리스트를 HTML 형식으로 포맷팅합니다.
    
    Args:
        products: 상품 리스트
        
    Returns:
        html: HTML 형식의 상품 정보
    """
    if not products:
        return "<p>상품을 찾을 수 없습니다.</p>"
    
    html = "<h3>추천 상품</h3>"
    html += "<div style='display: grid; grid-template-columns: repeat(3, 1fr); gap: 15px; max-width: 900px;'>"
    
    for i, product in enumerate(products[:6], 1):  # 3개에서 6개로 변경
        # 가격 처리 (문자열이거나 숫자일 수 있음)
        try:
            price = int(product.get('lprice', 0))
        except (ValueError, TypeError):
            price = 0
            
        # 브랜드/제조사 정보
        brand_info = ""
        if product.get('brand'):
            brand_info = f"<p style='color: #888; font-size: 12px; margin: 2px 0;'>브랜드: {product['brand']}</p>"
        elif product.get('maker'):
            brand_info = f"<p style='color: #888; font-size: 12px; margin: 2px 0;'>제조사: {product['maker']}</p>"
        
        # 카테고리 정보
        category_info = ""
        if product.get('category1'):
            categories = [product.get('category1', '')]
            if product.get('category2'):
                categories.append(product.get('category2'))
            category_info = f"<p style='color: #999; font-size: 11px; margin: 2px 0;'>{' > '.join(categories)}</p>"
        
        html += f"""
        <div style='border: 1px solid #ddd; border-radius: 8px; padding: 12px; background: #fafafa;'>
            <img src='{product.get('image', 'https://placehold.co/150')}' 
                 style='width: 100%; height: 120px; object-fit: cover; border-radius: 5px;'
                 onerror="this.onerror=null; this.src='https://placehold.co/150';">
            <h4 style='margin: 8px 0; font-size: 13px; line-height: 1.3; height: 32px; color: black; overflow: hidden;'>{product.get('title', '')[:40]}{'...' if len(product.get('title', '')) > 40 else ''}</h4>
            {brand_info}
            {category_info}
            <p style='color: #666; margin: 5px 0; font-size: 12px;'>쇼핑몰: {product.get('mallName', '')}</p>
            <p style='font-size: 16px; font-weight: bold; color: #ff6b6b;'>
                {price:,}원
            </p>
            <a href='{product.get('link', '#')}' target='_blank' rel='noreferrer noopener' 
               style='display: inline-block; background: #007bff; color: white; 
                      padding: 6px 14px; text-decoration: none; border-radius: 4px;
                      margin-top: 8px; font-size: 13px;'>
                구매하기
            </a>
        </div>
        """
    
    html += "</div>"
    return html

def should_search_web(query):
    """
    사용자 쿼리가 웹 검색이 필요한지 판단합니다.
    
    Args:
        query: 사용자 입력
        
    Returns:
        bool: 웹 검색 필요 여부
    """
    search_keywords = ['최신', '신상', '재고', '실시간', '현재', '오늘']
    
    return any(keyword in query for keyword in search_keywords)

def generate_response_with_context(user_input, conversation_history, search_results=None):
    """
    LLM을 사용하여 대화 컨텍스트를 고려한 응답을 생성합니다.
    
    Args:
        user_input: 사용자 입력
        conversation_history: 대화 히스토리
        search_results: 검색 결과 (선택사항)
        
    Returns:
        response: 생성된 응답
    """
    tokenizer = models['tokenizer']
    model = models['llm']
    
    # 시스템 프롬프트
    system_prompt = """당신은 친절한 AI 쇼핑 어시스턴트입니다. 패션 상품에 대한 정보를 제공하고 추천합니다. 
    간략하게 답변하세요. 모르면 모르겠다고 답하세요.
    반복되는 답변은 무조건 한 번만 하세요.
    같은 요청에 대한 답변은 동일한 답변 말고 다른 답변을 하세요.
    """
    
    # TokenManager로 프롬프트 준비
    full_prompt, prompt_tokens = token_manager.prepare_prompt(
        system_prompt=system_prompt,
        conversation_history=conversation_history,
        current_query=user_input,
        context=search_results
    )
    
    # 토큰화 및 attention_mask 생성
    inputs = tokenizer(full_prompt, return_tensors="pt", truncation=True, max_length=2048)
    
    # attention_mask 명시적으로 설정
    if 'attention_mask' not in inputs:
        inputs['attention_mask'] = torch.ones_like(inputs['input_ids'])
    
    with torch.no_grad():
        outputs = model.generate(
            inputs.input_ids.to(model.device),
            attention_mask=inputs.attention_mask.to(model.device),
            max_new_tokens=MAX_GENERATION_TOKENS,
            temperature=0.7,
            do_sample=True,
            pad_token_id=tokenizer.pad_token_id,
            eos_token_id=tokenizer.eos_token_id
        )
    
    # 생성된 텍스트에서 프롬프트 제거 및 정리
    generated_text = tokenizer.decode(outputs[0], skip_special_tokens=True)
    
    # 입력 프롬프트 길이 계산
    input_length = len(tokenizer.decode(inputs.input_ids[0], skip_special_tokens=True))
    
    # 생성된 부분만 추출 (입력 프롬프트 이후 텍스트)
    response = generated_text[input_length:].strip()
    
    # 대답이 이전 메시지 중 하나와 일치하면 "다르게" 리트라이
    previous_responses = [msg["content"] for msg in conversation_history if msg["role"] == "assistant"]
    if response in previous_responses:
        return generate_response_with_context(user_input + " (다르게)", conversation_history, search_results)

    # 응답이 너무 짧거나 비어있는 경우 기본 응답
    if len(response) < 5:
        response = "죄송합니다. 이해하지 못했습니다. 다시 한 번 말씀해 주시겠어요?"
    
    return response

# 예산 관련 함수들. 값만 받아와서 최대 가격으로 필터링할거임. 예산 금액이 최대 금액이 되게 끔. 다만 ~~만원으로 입력을 받아야 작동
import re
def parse_budget_request(message):
    budget_info = None
    price_match = re.search(r'(\d+)\s*(만원|천원|원)', message)
    if price_match:
        number, unit = price_match.groups()
        number = int(number)
        if unit == '만원':
            budget_info = number * 10000
        elif unit == '천원':
            budget_info = number * 1000
        else:  # '원'
            budget_info = number
            
    return budget_info

def apply_budget_filter(products, budget):
    filtered_products = []
    
    for p in products:
        try:
            price = int(p.get('lprice', 0))
            if budget and price > budget:
                continue # 예산 초과
            filtered_products.append(p)
        except:
            continue
    return sorted(filtered_products, key=lambda x: int(x.get('lprice', 0)))

def search_and_filter_products(message, budget):
    global search_count
    if should_search_web(message) and search_count < MAX_SEARCH_COUNT:
        print(f'\n웹 검색 : {message}\n')
        products = search_products(message)
        save_products_to_vectorstore(products)
    else:
        print(f'\n벡터 DB 검색 : {message}\n')
        docs = vector_store.similarity_search(message, k=VECTOR_SEARCH_K)
        products = []
        for doc in docs:
            if doc.metadata:
                product = {
                    'title': doc.metadata.get('title', ''),
                    'link': doc.metadata.get('link', ''),
                    'lprice': doc.metadata.get('price', '0'),
                    'hprice': doc.metadata.get('hprice', '0'),
                    'mallName': doc.metadata.get('mall', ''),
                    'image': doc.metadata.get('image', 'https://placehold.co/150'),
                    'brand': doc.metadata.get('brand', ''),
                    'maker': doc.metadata.get('maker', ''),
                    'category1': doc.metadata.get('category1', ''),
                    'category2': doc.metadata.get('category2', '')
                }
                products.append(product)
    return apply_budget_filter(products, budget)

def chat_response(message, history):
    """
    사용자 메시지에 대한 챗봇 응답을 생성합니다.
    
    Args:
        message: 사용자 메시지
        history: Gradio 대화 히스토리
        
    Returns:
        history: 업데이트된 대화 히스토리
    """
    if not message or not message.strip():
        return history, ""

    budget = parse_budget_request(message)
    
    conversation_history = []
    if history:
        for h in history:
            if isinstance(h, list) and len(h) == 2:
                user_msg_content, assistant_msg_content = h
                
                if not user_msg_content or not assistant_msg_content:
                    continue
                    
                user_msg_content = str(user_msg_content)
                assistant_msg_content = str(assistant_msg_content)
                
                user_msg = {"role": "user", "content": user_msg_content}
                assistant_msg = {"role": "assistant", "content": assistant_msg_content}
                
                if user_msg not in conversation_history:
                    conversation_history.append(user_msg)
                if assistant_msg not in conversation_history:
                    conversation_history.append(assistant_msg)

    conversation_history, token_count = token_manager.manage_conversation_history(
        conversation_history,
        {"role": "user", "content": message}
    )

    filtered_products = search_and_filter_products(message, budget)
    html_output = format_product_html(filtered_products)
    
    if filtered_products:
        search_results = format_product_list(filtered_products)
        response = generate_response_with_context(
            message,
            conversation_history,
            search_results
        )
        response += f"\n\n{search_results}"
    else:
        response = generate_response_with_context(
            message,
            conversation_history
        )
    
    conversation_history, _ = token_manager.manage_conversation_history(
        conversation_history,
        {"role": "assistant", "content": response}
    )
    
    token_stats = token_manager.get_token_stats(conversation_history)
    response += f"\n\n(Tip. '최신', '신상', '재고', '실시간', '현재', '오늘'  키워드를 포함해보세요.)"
    response += f"\n\n[검색: {search_count}/{MAX_SEARCH_COUNT}] [토큰: {token_stats['total']}/{MAX_CONTEXT_TOKENS}] [메시지: {token_stats['messages']}]"
    
    if history is None:
        history = []
    history.append([message, response])
    
    return history, html_output

def create_interface():
    """
    Gradio 인터페이스를 생성합니다.
    
    Returns:
        demo: Gradio Blocks 인터페이스
    """
    with gr.Blocks(title="AI 쇼핑 어시스턴트") as demo:
        gr.Markdown("# AI 쇼핑 어시스턴트")
        gr.Markdown("패션 이미지를 업로드하고 AI와 대화하며 쇼핑을 즐겨보세요!")
        
        with gr.Row():
            # 왼쪽 열: 이미지 업로드 및 탐지
            with gr.Column(scale=1):
                image_input = gr.Image(label="상품 이미지", type="pil")
                detect_btn = gr.Button("상품 탐지", variant="primary")
                output_image = gr.Image(label="탐지 결과")
                
            # 오른쪽 열: 채팅 인터페이스
            with gr.Column(scale=1):
                chatbot = gr.Chatbot(height=500)
                msg = gr.Textbox(
                    label="메시지",
                    placeholder="상품에 대해 궁금한 점을 물어보세요...",
                    lines=2
                )
                with gr.Row():
                    submit = gr.Button("전송", variant="primary")
                    clear = gr.Button("초기화")
        
        # 두번째 행 탐지 및 추천 상품 목록 표시
        with gr.Row():
            detection_info = gr.HTML(label="탐지 정보")
        
        # 이벤트 핸들러 연결
        def handle_detection_and_chat(image):
            """이미지 탐지 후 채팅 업데이트"""
            html = integrate_clip_search_to_detection(image)
            img, _ = detect_fashion_objects(image)
            
            # 탐지된 아이템으로 초기 메시지 생성
            detected_items = run_yolo_detection(image)
            if detected_items:
                detected_items_str = ', '.join(detected_items)
                initial_message = f"안녕하세요! 이미지에서 {detected_items_str}을(를) 발견했습니다. 어떤 스타일이나 브랜드를 선호하시나요? 예산도 알려주시면 더 정확한 추천을 도와드릴 수 있어요."
            else:
                initial_message = "안녕하세요! 이미지에서 패션 아이템을 찾지 못했습니다. 어떤 상품을 찾고 계신가요?"

            return img, html, [[None, initial_message]]
        
        detect_btn.click(
            fn=handle_detection_and_chat,
            inputs=image_input,
            outputs=[output_image, detection_info, chatbot]
        )
        
        # 메시지 전송 이벤트
        msg.submit(fn=chat_response, inputs=[msg, chatbot], outputs=[chatbot, detection_info]).then(
            fn=lambda: "", outputs=msg
        )
        submit.click(fn=chat_response, inputs=[msg, chatbot], outputs=[chatbot, detection_info]).then(
            fn=lambda: "", outputs=msg
        )
        
        # 대화 초기화 함수
        def clear_conversation():
            global search_count
            search_count = 0
            return None, "", None
        
        clear.click(clear_conversation, outputs=[chatbot, msg])
    
    return demo

if __name__ == "__main__":
    print("AI 쇼핑 어시스턴트 시작...")
    print("모델 로딩 중...")
    load_models()
    print("서버 시작...")
    
    demo = create_interface()
    demo.launch(
        server_port=GRADIO_SERVER_PORT,
        server_name=GRADIO_SERVER_NAME,
        share=False  # 공개 URL 생성 여부
    )